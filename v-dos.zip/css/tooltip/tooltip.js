$(document).ready(function(){
    $("[rel=tooltip-r]").tooltip({ placement: 'right'});
});
$(document).ready(function(){
    $("[rel=tooltip-b]").tooltip({ placement: 'bottom'});
});
$(document).ready(function(){
    $("[rel=tooltip]").tooltip({ placement: 'top'});
});