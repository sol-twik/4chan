<?php
ob_start();
error_reporting(0);
require_once 'includes/db.php';
require_once 'includes/init.php';
if (!($user -> LoggedIn()))
{
	header('location: login.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | TOS</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>				

<h2>TOS:</h2>
1) By purchasing StrikeREAD Stresser you agree to our ToS.<br />
2) We are not responsible for how ever you use this stresser.<br />
3) You may not share your account, if you will, your account will be closed without a warning or a refund!<br />
4) We have the right to close any account we want or shut down the project at any time we want without a refund.<br />
5) No Refunds or chargebacks unless we decide , if you'll charge back a report will be filled.<br />
6) We have the right not to sell you any plan / spot in StrikeREAD.<br />
7) We have the right to change the ToS anytime we want.<br />
8) You're not allowed to use proxy or VPN to access StrikeREAD stresser.<br />
9) Disrespect will result in no more support & no more updates.<br />
10) You're not allowed to have more than 4 accounts.

</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>