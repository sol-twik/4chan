
var data = { 
  labels: ['12/12/2013','13/12/2013','14/12/2013','14/12/2013','15/12/2013','16/12/2013','17/12/2013'],
   datasets: [
     { data: [1000,600,250,700,201,190,192], fillColor: 'rgba(31,200,248,0.1)', strokeColor: '#1fc8f8', pointColor: '#1fc8f8', pointStrokeColor: '#1fc8f8' },
    ]
};
           
var line = document.getElementById('line');
var lineCtx = line.getContext('2d');
var chart1 = new Chart(lineCtx).Line(data);