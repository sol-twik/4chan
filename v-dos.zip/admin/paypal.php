<?php
	ob_start();
	require_once('../includes/db.php');
	require_once('../includes/init.php');
	if(!($user->LoggedIn())){
		header('location: ../login.php');
		die();
	}
	if(!($user->isAdmin($odb))){
		header('location: ../index.php');
	}
	if(!($user->notBanned($odb))){
		header('location: ../logout.php');
		die();
	}
?>
				<html lang="en">
    
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Edit paypal</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='../css/system.css' />
<link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='../css/tooltip/tooltip.js'></script>
</head>
    <body>
        
        <div class="page-container">
            
            <div id='sidebar'>
				<?php 
				include("sidebar.php"); 
				?>
				
<div class='content-page'>
									<form method="POST">
										<?php
											if(isset($_POST['changeBtn'])){
												$paypalemail = $_POST['emailChange'];
												$errors = array();
												if(empty($paypalemail)){
													$errors[] = 'Please verify all fields';
												}
												if(empty($errors)){
													$SQLinsert = $odb->prepare("UPDATE `gateway` SET `email` = :newemail");
													$SQLinsert->execute(array(':newemail' => $paypalemail));
													echo $design->alert('message', 'Success', 'Paypal Email Has Been Updated!');
												} else {
													echo $design->alert('error', 'Error', 'Please Verify All The Fields!');
												}
											}
											if(isset($_POST['changesBtn'])){
												$sitename = $_POST['sitename'];
												$errors = array();
												if(empty($sitename)){
													$errors[] = 'Please verify all fields';
												}
												if(empty($errors)){
													$SQLinsert = $odb->prepare("UPDATE `sitename` SET `sitename` = :sitename");
													$SQLinsert->execute(array(':sitename' => $sitename));
													echo $design->alert('success', 'Success', 'Site Name Has Been Updated!');
												} else {
													echo $design->alert('danger', 'Error', 'Please Verify All The Fields!');
												}
											}
											if(isset($_POST['changessBtn'])){
												$skypeapi= $_POST['skypeapi'];
												$errors = array();
												if(empty($skypeapi)){
													$errors[] = 'Please verify all fields';
												}
												if(empty($errors)){
													$SQLinsert = $odb->prepare("UPDATE `skypeapi` SET `skypeapi` = :skypeapi");
													$SQLinsert->execute(array(':skypeapi' => $skypeapi));
													echo $design->alert('success', 'Success', 'Skype API Has Been Updated!');
												} else {
													echo $design->alert('danger', 'Error', 'Please Verify All The Fields!');
												}
											}
										?>
											<label>Site Paypal Email</label>
											<input type="text" class="login-input" name="emailChange" value="<?php echo $odb->query("SELECT `email` FROM `gateway` LIMIT 1")->fetchColumn(0); ?>" placeholder="Site Paypal Email Here!"/>
										<button type="submit" name="changeBtn" class="login-input">Update Paypal Email</button>
									</form>
								<script>
    $(".content-page").fadeIn(350);
</script>