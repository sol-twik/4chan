<?php	ob_start();	require_once('../includes/db.php');	require_once('../includes/init.php');	if(!($user->LoggedIn())){		header('location: ../login.php');		die();	}	if(!($user->isAdmin($odb))){		header('location: ../index.php');	}	if(!($user->notBanned($odb))){		header('location: ../logout.php');		die();	}?><html lang="en">    <head><script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script><title>StrikeREAD Stresser | Manage Users</title><meta http-equiv='content-type' content='text/html; charset=UTF-8' /><link rel='stylesheet' type='text/css' href='../css/system.css' /><link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' /><link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'><script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script><script type='text/javascript' src='../css/tooltip/tooltip.js'></script></head>    <body>                <div class="page-container">                        <div id='sidebar'>				<?php 				include("sidebar.php"); 				?>				<div class='content-page'><form method="POST">

											<table id="eix">
												<thead>
													<tr>
														<th>ID</th>
														<th>Username</th>
														<th>Email</th>
														<th>Rank</th>
														<th>Skype</th>
														<th>Manage</th>
													</tr>
												</thead>
												<tbody>
													<?php
														$viewUsers = $odb->query("SELECT * FROM `users` ORDER BY `ID` DESC");
														while($getInfo = $viewUsers->fetch(PDO::FETCH_ASSOC)){
															$id = $getInfo['ID'];
															$uid = $getInfo['uid'];
															$user = $getInfo['username'];
															$email = $getInfo['email'];
															$rank = ($getInfo['rank'] == 1) ? 'Admin' : 'Member';
													?>
													<tr>
														<td style='text-align:center;'><?php echo $id; ?></td>
														<td style='text-align:center;'><?php echo $user; ?></td>
														<td style='text-align:center;'><?php echo $email; ?></td>
														<td style='text-align:center;'><?php echo $rank; ?></td>
														<td style='text-align:center;'><button type="submit" class="login-input" onClick="window.open('skype:add<?php echo $uid; ?>');"><?php echo $uid; ?></button></td>
														<td style='text-align:center;'><button type="submit" class="login-input" onClick="javascript: form.action='edit-user.php?id=<?php echo $id; ?>';">Edit</button></td>
													</tr>
													<?php
														}
													?>
												</tbody>
											</table>
										
									</form>
								</tbody><script>    $(".content-page").fadeIn(350);</script>