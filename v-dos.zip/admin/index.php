<?php
	require_once '../includes/db.php';
	require_once '../includes/init.php';
	header('Location: '.$url.'');
?>