<?php
	ob_start();
	require_once('../includes/db.php');
	require_once('../includes/init.php');
	if(!($user->LoggedIn())){
		header('location: ../login.php');
		die();
	}
	if(!($user->isAdmin($odb))){
		header('location: ../index.php');
	}
	if(!($user->notBanned($odb))){
		header('location: ../logout.php');
		die();
	}
?>

<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Manage News</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='../css/system.css' />
<link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='../css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
	<div class='content-page'>
	<h2>Add News:</h2>
				<div class="row">
									<form method="POST">
										<?php 
											if(isset($_POST['addBtn'])){
												$titleAdd = $_POST['titleAdd'];
												$detailAdd = $_POST['detailAdd'];
												if(!empty($titleAdd) && !empty($detailAdd)){
													$SQLinsert = $odb->prepare("INSERT INTO `news` VALUES(NULL, :title, :detail, UNIX_TIMESTAMP())");
													$SQLinsert->execute(array(':title' => $titleAdd, ':detail' => $detailAdd));
													echo $design->alert('message', 'Success', 'News Has Been Posted!');
												} else {
													echo $design->alert('error', 'Error', 'Please Fill In All Fields!');
												}
											}
										?>
											<input type="text" class="login-input" name="titleAdd" placeholder="New Title Here!"/><br>
											<textarea class="login-input" name="detailAdd" placeholder="Details Here!" rows="10"></textarea><br>
										<button type="submit" name="addBtn" class="login-input">Add</button>
									</form>
					</div>
						
				
	<h2>Current New(s)</h2>
				<div class="row">
									<form method="POST">
										<?php
											if(isset($_POST['deleteBtn'])){
												if(empty($_POST['deleteCheck'])){
													echo $design->alert('error', 'Error', 'Nothing Is Checked!');
												} else {
													$deletes = $_POST['deleteCheck'];
													foreach($deletes as $delete){
														$SQL = $odb->prepare("DELETE FROM `news` WHERE `ID` = :id LIMIT 1");
														$SQL->execute(array(':id' => $delete));
													}
													echo $design->alert('message', 'Success', 'New(s) Have Been Been Removed!');
												}
											}
										?>
											<table id="eix">
												<thead>
													<tr>
														<th>Checkbox</th>
														<th>Title</th>
														<th>Details</th>
													</tr>
												</thead>
												<tbody>
													<?php
														$SQLSelect = $odb->query("SELECT * FROM `news` ORDER BY `date` DESC");
														while($show = $SQLSelect->fetch(PDO::FETCH_ASSOC)){
															$titleShow = $show['title'];
															$detailShow = $show['detail'];
															$rowID = $show['ID'];
													?>
													<tr>
														<td style='text-align:center;'><input type="checkbox" name="deleteCheck[]" value="<?php echo $rowID; ?>"/></td>
														<td style='text-align:center;'><?php echo htmlentities($titleShow); ?></td>
														<td style='text-align:center;'><?php echo htmlentities($detailShow); ?></td>
													</tr>
												<?php
													}
												?>
												</tbody>
											</table>
											<button type="submit" name="deleteBtn" class="login-input">Delete</button>
										</div>
									</form>
							
						</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>
					