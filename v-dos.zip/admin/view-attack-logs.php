<?php	ob_start();	require_once('../includes/db.php');	require_once('../includes/init.php');	if(!($user->LoggedIn())){		header('location: ../login.php');		die();	}	if(!($user->isAdmin($odb))){		header('location: ../index.php');	}	if(!($user->notBanned($odb))){		header('location: ../logout.php');		die();	}?>				<html lang="en">    <head><script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script><title>StrikeREAD Stresser | Attack Logs</title><meta http-equiv='content-type' content='text/html; charset=UTF-8' /><link rel='stylesheet' type='text/css' href='../css/system.css' /><link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' /><link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'><script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script><script type='text/javascript' src='../css/tooltip/tooltip.js'></script></head>    <body>                <div class="page-container">                        <div id='sidebar'>				<?php 				include("sidebar.php"); 				?>				<div class='content-page'>									<form method="POST">
										<?php
											if(isset($_POST['clearAttack'])){
												$SQL = $odb->prepare("TRUNCATE TABLE `logs`");
												$SQL->execute();
												echo $design->alert('success', 'Success', 'You successfully cleared all attack logs!');
											}
										?>
									
											<table id="eix">
												<thead>
													<tr>
														<th>User</th>
														<th>IP</th>
														<th>Port</th>
														<th>Time</th>
														<th>Method</th>
														<th>Date</th>
													</tr>
												</thead>
												<tbody>
												<?php
													$attackLogs = $odb->query("SELECT * FROM `logs` ORDER BY `date` DESC");
													while($getInfo = $attackLogs->fetch(PDO::FETCH_ASSOC)){
														$user = $getInfo['user'];
														$IP = $getInfo['ip'];
														$port = $getInfo['port'];
														$method = $getInfo['method'];
														$time = $getInfo['time'];
														$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
												?>
													<tr>
														<td style='text-align:center;'><?php echo $user; ?></td>
														<td style='text-align:center;'><?php echo $IP; ?></td>
														<td style='text-align:center;'><?php echo $port; ?></td>
														<td style='text-align:center;'><?php echo $method; ?></td>
														<td style='text-align:center;'><?php echo $time; ?></td>
														<td style='text-align:center;'><?php echo $date; ?></td>
													</tr>
												<?php
													}
												?>
												</tbody>
											</table>
											<button type="submit" name="clearAttack" class="login-input">Clear Attack Logs</button>
										
									</form>								</tbody><script>    $(".content-page").fadeIn(350);</script>