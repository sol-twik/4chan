<?php	ob_start();	require_once('../includes/db.php');	require_once('../includes/init.php');	if(!($user->LoggedIn())){		header('location: ../login.php');		die();	}	if(!($user->isAdmin($odb))){		header('location: ../index.php');	}	if(!($user->notBanned($odb))){		header('location: ../logout.php');		die();	}?><html lang="en">    <head><script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script><title>StrikeREAD Stresser | Manage Blacklist</title><meta http-equiv='content-type' content='text/html; charset=UTF-8' /><link rel='stylesheet' type='text/css' href='../css/system.css' /><link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' /><link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'><script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script><script type='text/javascript' src='../css/tooltip/tooltip.js'></script></head>    <body>                <div class="page-container">                        <div id='sidebar'>				<?php 				include("sidebar.php"); 				?>				<div class='content-page'><h2>Add Blacklist</h2><form method="POST">
										<?php 
											if(isset($_POST['addBtn'])){
												$ipAdd = $_POST['ipAdd'];
												$noteAdd = $_POST['noteAdd'];
												$errors = array();
												if(!filter_var($ipAdd, FILTER_VALIDATE_IP)){
													$errors[] = 'IP is invalid';
												}
												if(empty($ipAdd)){
													$errors[] = 'Please verify all fields';
												}
												if(empty($errors)){
													$SQLinsert = $odb->prepare("INSERT INTO `blacklist` VALUES(NULL, :ip, :note)");
													$SQLinsert->execute(array(':ip' => $ipAdd, ':note' => $noteAdd));
													echo $design->alert('message', 'Success', 'IP Has Been Added!');
												} else {
													echo '<div class="error" id="message"><p><strong>Error:</strong> <br/></div>';
													foreach($errors as $error){
														echo ''.$error.'!<br/>';
													}
													echo ' </div>';
												}
											}
										?>
											<input type="text" class="login-input" name="ipAdd" placeholder="IP Address Here!"/><br>
											<textarea class="login-input" name="noteAdd" placeholder="Reason Here!" rows="3"></textarea><br><br>
										<button type="submit" name="addBtn" class="login-input">Add</button>
									</form><h2>BlackList</h2>
									<form method="POST">
										<?php
											if(isset($_POST['deleteBtn'])){
												if(empty($_POST['deleteCheck'])){
													echo $design->alert('error', 'Error', 'Nothing Is Checked!');
												} else {
													$deletes = $_POST['deleteCheck'];
													foreach($deletes as $delete){
														$SQL = $odb->prepare("DELETE FROM `blacklist` WHERE `ID` = :id LIMIT 1");
														$SQL->execute(array(':id' => $delete));
													}
													echo $design->alert('massage', 'Success', 'IP(s) Have Been Been Removed!');
												}
											}
										?>
											<table id="eix">
												<thead>
													<tr>
														<th>Checkbox</th>
														<th>IP</th>
														<th>Note</th>
													</tr>
												</thead>
												<tbody>
													<?php
														$SQLSelect = $odb->query("SELECT * FROM `blacklist` ORDER BY `ID` DESC");
														while($show = $SQLSelect->fetch(PDO::FETCH_ASSOC)){
															$ipShow = $show['IP'];
															$noteShow = $show['note'];
															$rowID = $show['ID'];
													?>
													<tr>
														<td style='text-align:center;'><input type="checkbox" name="deleteCheck[]" value="<?php echo $rowID; ?>"/></td>
														<td style='text-align:center;'><?php echo $ipShow; ?></td>
														<td style='text-align:center;'><?php echo htmlentities($noteShow); ?></td>
													</tr>
												<?php
													}
												?>
												</tbody>
											</table>
											<button type="submit" name="deleteBtn" class="login-input">Delete</button>
										</div>
									</form></tbody><script>    $(".content-page").fadeIn(350);</script>					