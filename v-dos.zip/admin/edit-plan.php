<?php
	ob_start();
	require_once('../includes/db.php');
	require_once('../includes/init.php');
	if(!($user->LoggedIn())){
		header('location: ../login.php');
		die();
	}
	if(!($user->isAdmin($odb))){
		header('location: ../index.php');
	}
	if(!($user->notBanned($odb))){
		header('location: ../logout.php');
		die();
	}
	
	if(!isset($_GET['id'])){
		header('location: ../index.php');
	}
	
	$SQLGetInfo = $odb -> prepare("SELECT * FROM `plans` WHERE `ID` = :id LIMIT 1");
	$SQLGetInfo -> execute(array(':id' => $_GET['id']));
	$planInfo = $SQLGetInfo -> fetch(PDO::FETCH_ASSOC);
	$currentName = $planInfo['name'];
	$currentDescription = $planInfo['description'];
	$currentMbt = $planInfo['mbt'];
	$currentUnit = $planInfo['unit'];
	$currentPrice = $planInfo['price'];
	$currentLength = $planInfo['length'];
	function selectedUnit($check, $currentUnit){
		if($currentUnit == $check){
			return 'selected="selected"';
		}
	}
?>
<html lang="en">
    
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Edit Plans</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='../css/system.css' />
<link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='../css/tooltip/tooltip.js'></script>
</head>
    <body>
        
        <div class="page-container">
            
            <div id='sidebar'>
				<?php 
				include("sidebar.php"); 
				?>
				
<div class='content-page'>
<h2>Edit Plan</h2>
				
									<form method="POST">
										<?php
											if(isset($_POST['updateBtn'])){
												$updateName = $_POST['nameAdd'];
												$updateDescription = $_POST['descriptionAdd'];
												$updateUnit = $_POST['unit'];
												$updateLength = $_POST['lengthAdd'];
												$updateMbt = intval($_POST['mbt']);
												$updatePrice = floatval($_POST['price']);
												$errors = array();
												if(empty($updatePrice) || empty($updateName) || empty($updateDescription) || empty($updateUnit) || empty($updateLength) || empty($updateMbt)){
													$errors[] = 'Fill in all fields';
												}
												if(empty($errors)){
													$SQLinsert = $odb -> prepare("UPDATE `plans` SET `name` = :name, `description` = :description, `mbt` = :mbt, `unit` = :unit, `length` = :length, `price` = :price WHERE `ID` = :id");
													$SQLinsert -> execute(array(':name' => $updateName, ':description' => $updateDescription, ':mbt' => $updateMbt, ':unit' => $updateUnit, ':length' => $updateLength, ':price' => $updatePrice, ':id' => $_GET['id']));
													echo '<section class="g_1"><div class="dialog-big success"><h3> SUCCESS: </h3><span>x</span><div> Plan Has Been Updated! </div></div>';
													$currentName = $updateName;
													$currentDescription = $updateDescription;
													$currentUnit = $updateUnit;
													$currentMbt = $updateMbt;
													$currentPrice = $updatePrice;
													$currentLength = $updateLength;
												} else {
													echo '<section class="g_1"><div class="dialog-big error"><h3> ERROR: </h3><span>x</span><div> ';
													foreach($errors as $error){
														echo '- '.$error.'<br />';
													}
													echo ' </div></div>';
												}
											}
										?>
										
											<label>Name</label><br>
											<input type="text" class="login-input" name="nameAdd" placeholder="Name" value="<?php echo htmlentities($currentName); ?>"/><br><br>
										
											<label>Description</label><br>
											<textarea class="login-input" name="descriptionAdd" placeholder="Description" rows="12"><?php echo htmlentities($currentDescription); ?></textarea><br><br>
										
											<label>Max Boot Time</label><br>
											<input type="text" class="login-input" name="mbt" placeholder="Max Boot Time" value="<?php echo htmlentities($currentMbt); ?>"/><br><br>
										
											<label>Unit</label>
											<select class="login-input" name="unit">
												<option value="Days" <?php echo selectedUnit('Days',$currentUnit); ?> >Days</option>
												<option value="Weeks" <?php echo selectedUnit('Weeks', $currentUnit); ?> >Weeks</option>
												<option value="Months" <?php echo selectedUnit('Months', $currentUnit); ?> >Months</option>
												<option value="Years" <?php echo selectedUnit('Years', $currentUnit); ?> >Years</option>
											</select><br><br>
										
											<label>Length</label><br>
											<input type="text" class="login-input" name="lengthAdd" placeholder="Length" value="<?php echo htmlentities($currentLength); ?>"/><br><br>
										
											<label>Price</label>
											<input type="text" class="login-input" name="price" placeholder="Price" value="<?php echo htmlentities($currentPrice);?>"/><br><br>
											
										
										<button type="submit" name="updateBtn" class="login-input">Update</button>
									</form>
								
							</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>