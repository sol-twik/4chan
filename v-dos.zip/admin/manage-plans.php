<?php
	ob_start();
	require_once('../includes/db.php');
	require_once('../includes/init.php');
	if(!($user->LoggedIn())){
		header('location: ../login.php');
		die();
	}
	if(!($user->isAdmin($odb))){
		header('location: ../index.php');
	}
	if(!($user->notBanned($odb))){
		header('location: ../logout.php');
		die();
	}
?>
<html lang="en">
    
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Manage Plans</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='../css/system.css' />
<link href='../css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='../css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='../css/tooltip/tooltip.js'></script>
</head>
    <body>
        
        <div class="page-container">
            
            <div id='sidebar'>
				<?php 
				include("sidebar.php"); 
				?>
				
<div class='content-page'>
<h2>Adding New Plan</h2>
<form method="POST">
										<?php
											if(isset($_POST['addBtn'])){
												$nameAdd = $_POST['nameAdd'];
												$descriptionAdd = $_POST['descriptionAdd'];
												$unitAdd = $_POST['unit'];
												$lengthAdd = $_POST['lengthAdd'];
												$mbtAdd = intval($_POST['mbt']);
												$priceAdd = floatval($_POST['price']);
												if(empty($priceAdd) || empty($nameAdd) || empty($descriptionAdd) || empty($unitAdd) || empty($lengthAdd) || empty($mbtAdd)){
													echo $design->alert('error', 'Error', 'Please Fill In All The Fields!');
												} else {
													$SQLinsert = $odb->prepare("INSERT INTO `plans` VALUES(NULL, :name, :description, :mbt, :unit, :length, :price)");
													$SQLinsert->execute(array(':name' => $nameAdd, ':description' => $descriptionAdd, ':mbt' => $mbtAdd, ':unit' => $unitAdd, ':length' => $lengthAdd, ':price' => $priceAdd));
													echo $design->alert('message', 'Success', 'Plan Has Been Created!');
												}
											}
										?>
											<input type="text" class="login-input" name="nameAdd" placeholder="Plan Name!"/><br>
											<textarea class="login-input" name="descriptionAdd" placeholder="Plan Description!" rows="4"></textarea><br>
											<input type="text" class="login-input" name="mbt" placeholder="Max Boot Time!"/><br>
											<select class="login-input" name="unit">
												<option value="Days">Days</option>
												<option value="Weeks">Weeks</option>
												<option value="Months">Months</option>
												<option value="Years">Years</option>
											</select><br>
											<input type="text" class="login-input" name="lengthAdd" placeholder="Plan Length!"/><br>
											<input type="text" class="login-input" name="price" placeholder="Plan Price!"/><br>
										<button type="submit" name="addBtn" class="login-input">Add</button>
									</form><br><br>
								<h2>Delete Plan(s)</h2>
									<form method="POST">
										<?php
											if(isset($_POST['deleteBtn'])){
												if(empty($_POST['deleteCheck'])){
													echo $design->alert('error', 'Error', 'Nothing Is Checked!');
												} else {
													$deletes = $_POST['deleteCheck'];
													foreach($deletes as $delete){
														$SQL = $odb->prepare("DELETE FROM `plans` WHERE `ID` = :id LIMIT 1");
														$SQL->execute(array(':id' => $delete));
													}
													echo $design->alert('message', 'Success', 'Plan(s) Have Been Removed!');
												}
											}
										?>
											<table id="eix">
												<thead>
													<tr>
														<th>Checkbox</th>
														<th>Name</th>
														<th>Max Boot Time</th>
														<th>Description</th>
													</tr>
												</thead>
												<tbody>
													<?php
														$SQLSelect = $odb->query("SELECT * FROM `plans` ORDER BY `price` ASC");
														while($show = $SQLSelect->fetch(PDO::FETCH_ASSOC)){
															$planName = $show['name'];
															$noteShow = $show['description'];
															$mbtShow = $show['mbt'];
															$rowID = $show['ID'];
													?>
													<tr>
														<td style='text-align:center;'><input type="checkbox" name="deleteCheck[]" value="<?php echo $rowID; ?>"/></td>
														<td style='text-align:center;'><a href="edit-plan.php?id=<?php echo $rowID; ?>"><?php echo htmlentities($planName); ?></a></td>
														<td style='text-align:center;'><?php echo $mbtShow; ?></td>
														<td style='text-align:center;'><?php echo htmlentities($noteShow); ?></td>
													</tr>
												<?php
													}
												?>
												</tbody>
											</table>
											<button type="submit" name="deleteBtn" class="login-input">Delete</button>
										</div>
									</form>
								</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>