<!-- Sidebar -->
    <?php
	$plansql = $odb->prepare("SELECT `users`.*,`plans`.`name`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id LIMIT 1");
	$plansql->execute(array(":id" => $_SESSION['ID']));
	$userInfo = $plansql->fetch(PDO::FETCH_ASSOC);
	$test = $odb->prepare("SELECT `email` FROM `users` WHERE `ID` = :id LIMIT 1");
	$test->execute(array(":id" => $_SESSION['ID']));
	$testInfo = $test->fetch(PDO::FETCH_ASSOC);
	$loginLogs = $odb->query("SELECT COUNT(*) FROM `loginip` WHERE `username` = '{$_SESSION['username']}'");
	$attackLogs = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `user` = '{$_SESSION['username']}'");
	$purchaseLogs = $odb->query("SELECT COUNT(*) FROM `payments` WHERE `user` = '{$_SESSION['ID']}'");	
	?>
	
	<input type='image' src='../css/images/EIX.png' width='100%'/>
		<h3></h3>
		<h3 style='font-size: 13px;'>Logged as: <u><?php echo htmlentities($_SESSION['username']); ?></u><br />
        <br>Account type: Normal
		<br>Your boots: <?php echo $stats->totalBootsForUser($odb, $_SESSION['username']); ?>
		<br>Account status: Active
		<br>Account package: <?php echo $userInfo['name']; ?>
		<br>Account expire date: <?php echo date('d-m-Y' ,$userInfo['expire']); ?>
		<br>Account max boot time: <?php echo $userInfo['mbt']; ?> seconds
        <h3 style='font-size: 10px;'>
       There are 7 stressing servers. #Online<br> 
	   There are 1 stressing server. #Offline<br>
	   Total boots: <?php echo $stats->totalBoots($odb); ?>.<br>
	   Total users: <?php echo $stats->totalUsers($odb); ?>.<br>
	   
	   </h3>
         <h3 style='font-size: 9px;'>#StrikeREAD<br>
		</h3> <a href='skype:alediezpd?chat' rel='tooltip' title='Skype support' class='fa fa-skype'></a> <a href='' rel='tooltip' title='Follow us' class='fa fa-twitter'><br></a></div>
		<div id='main'>
		 <div class='page'>
		 <?php
		if ($user -> isAdmin($odb))
		{
		
		?>
		 <a href="admin.php">Index Admin</a>
		 <a href="manage-news.php">News</a>
		 <a href='manage-blacklisting.php'>Blacklist</a>
		 <a href="manage-users.php">Users</a>
		 <a href='manage-plans.php'>Plans</a>
		 <a href='paypal.php'>PayPal Email</a>
		 <a href='view-attack-logs.php'>View Attack Logs</a>
		 <a href='view-login-logs.php'>View Login Logs</a>
		 <a href='view-payment-logs.php'>View purchase Logs</a>
		 <a href='../index.php'><i class="fa fa-sign-in"></i> Logout</a>
		<?php
		}
		?>

<!-- Sidebar end | StrikeREAD -->