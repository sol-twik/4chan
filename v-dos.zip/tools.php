<?php
ob_start();
error_reporting(0);
require_once 'includes/db.php';
require_once 'includes/init.php';
if (!($user -> LoggedIn()))
{
	header('location: login.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>DDosCity | Tools</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>				

<h2>Domain Resolver:</h2>
<form method="POST">
<?php
$dr = '';
if (isset($_POST['drBtn']))
{
$domain = $_POST['domain'];
if($domain == ''){
$dr = gethostbyname("www.google.com");
}
$dr = gethostbyname($domain);
}
?>
<input type="text" class="login-input" name="domain" id="domain" placeholder="www.domain.com" value="<?php echo $domain; ?>"/>
<input type="text" class="login-input" name="dr" placeholder="Ip Address" value="<?php echo $dr; ?>" disabled readonly/>
<button type="submit" name="drBtn" class="login-input">Resolve Domain</button>
</form><br><br>

<h2>Skype Resolver:</h2>
<form method="POST">
<?php
								//Variable POST username
								$username = $_POST['username'];
								 
								//Function cURL                        
								function get_data($url) // Your main function to resolve
								{
								  $ch = curl_init();
								  $timeout = 5;
								  curl_setopt($ch,CURLOPT_URL,$url);
								  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
								  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
								  $data = curl_exec($ch);
								  curl_close($ch);
								  return $data;
								}      
								if (isset($_POST['resolve']))
												strtolower($username);
												if($username == null){								
												} else
												if($username == "test" || $username == "alediezpd"){
												echo '<div class="error" id="message"><center>Blacklisted username.<br><img src="http://api.skype.com/users/'.$username.'/profile/avatar" width="100" height="100"/><br><b>Username:</b> '.$username.'</center></div>';																							
												
												} else {
												$resolve = file_get_contents("http://www.swiftresolver.com/resolver.php?name={$username}");
												echo '<div class="message" id="message"><center><img src="http://api.skype.com/users/'.$username.'/profile/avatar" width="100" height="100"/><br><b>Username:</b> '.$username.' <br><b>IP</b>: '.$resolve.'</center></div>';																																					
									}
									
									?>
<input type="text" class="login-input" name="username" id="username" placeholder="echo123"/>
<button type="submit" name="resolve" class="login-input">Resolve</button>
</form><br><br>

<h2>Ip To Skype:</h2>
<form method="POST">
<?php
								//Variable POST Ip
								$ip = $_POST['ip'];
								 
								//Function cURL                        
								function get_ip($url) // Your main function to resolve
								{
								  $ch = curl_init();
								  $timeout = 5;
								  curl_setopt($ch,CURLOPT_URL,$url);
								  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
								  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
								  $data = curl_exec($ch);
								  curl_close($ch);
								  return $data;
								}      
								if (isset($_POST['resolveusername']))
												strtolower($ip);
												if($ip == null){
												} else
												if($username == "test" || $username == "alediezpd"){
												echo '<div class="error" id="message"><center>Blacklisted username.<br><img src="http://api.skype.com/users/'.$username.'/profile/avatar" width="100" height="100"/><br><b>Username:</b> '.$username.'</center></div>';																							
												
																						
												} else {
												$resolveusername = get_ip("http://api.strikeread.ml/apiip2skype.php?ip={$ip}");
												echo '<div class="message" id="message"><center><b>Username:</b> '.$resolveusername.' <br><b>IP</b>: '.$ip.'</center></div>';	
											}
										
									?>
<input type="text" class="login-input" name="ip" id="ip" placeholder="echo123"/>
<button type="submit" name="resolveusername" class="login-input">Resolve</button>
</form><br><br>

</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>