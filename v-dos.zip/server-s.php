<?php
ob_start();
error_reporting(0);
require_once 'includes/db.php';
require_once 'includes/init.php';
if (!($user -> LoggedIn()))
{
	header('location: login.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Server Status</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>				
		
<h2>Server(s) status:</h2>
<table id='eix'>
<thead>
<tr>
<td>Server</td>
<td>Status <A title="90% Load" rel='tooltip' herf='#' class='icon-info-sign'></a></h2> </td>
<td>Type</td>
<td>Power</td>
</tr>
</thead>
<tbody>

<tr>
	<td style='text-align:center;'>Alpha</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='5GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 100%</a></td>
<tr>
	<td style='text-align:center;'>Bravo</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='10GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 100%</a></td>
<tr>
	<td style='text-align:center;'>Charlie</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='15GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 100%</a></td>
<tr>
	<td style='text-align:center;'>Delta</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='19,3GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 97%</a></td>
<tr>
	<td style='text-align:center;'>Echo</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='10GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 100%</a></td>
<tr>
	<td style='text-align:center;'>Layer 7</td>
	<td style='text-align:center;'><img src='css/images/online.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='15GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 100%</a></td>
<tr>
	<td style='text-align:center;'>Extreme Power</td>
	<td style='text-align:center;'><img src='css/images/offline.gif'/></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r title='50GB Load'>Spoofed</a></td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Power Load : 0% | Offline</a></td>

</table>
</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>