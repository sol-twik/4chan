<?php
	ob_start();
	require_once('includes/db.php');
	require_once('includes/init.php');
	if(!($user->LoggedIn())){
		if(isset($_GET['referral'])){
			$_SESSION['referral'] = preg_replace("/[^A-Za-z0-9-]/","", $_GET['referral']);
			header('Location: register.php');
			die();
		}
		header('location: login.php');
		die();
	}
	if(!($user->notBanned($odb))){
		header('location: logout.php');
		die();
	}
	
	$plansql = $odb->prepare("SELECT `users`.*,`plans`.`name`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id LIMIT 1");
	$plansql->execute(array(":id" => $_SESSION['ID']));
	$userInfo = $plansql->fetch(PDO::FETCH_ASSOC);
	$test = $odb->prepare("SELECT `email` FROM `users` WHERE `ID` = :id LIMIT 1");
	$test->execute(array(":id" => $_SESSION['ID']));
	$testInfo = $test->fetch(PDO::FETCH_ASSOC);
	$loginLogs = $odb->query("SELECT COUNT(*) FROM `loginip` WHERE `username` = '{$_SESSION['username']}'");
	$attackLogs = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `user` = '{$_SESSION['username']}'");
	$purchaseLogs = $odb->query("SELECT COUNT(*) FROM `payments` WHERE `user` = '{$_SESSION['ID']}'");
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Index</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>

<h2>News:</h2>
<table id='eix'>
<thead>
</thead>
<tbody>

<?php
					$SQLNews = $odb->query("SELECT `title`,`detail`,`date` FROM `news` ORDER BY `date` DESC LIMIT 5");
					while($newsInfo = $SQLNews->fetch(PDO::FETCH_ASSOC)){
				?>
<div class="row">
<tr>
	<td style='text-align:center;'><?php echo $newsInfo['title']; ?> | <?php echo date('d-m-Y', $newsInfo['date']); ?></td>
	<td style='text-align:center;'><a href='' title='by StrikeREAD' rel=tooltip-r><?php echo $newsInfo['detail']; ?></a></td>
</div>
<?php
					}
				?>
<tr>
<?php
					$totalNews = $odb->query("SELECT COUNT(*) FROM `news`");
					if($totalNews->fetchColumn(0) == 0){
				?>
<div class="row">
<tr>
	<td style='text-align:center;'>No news</td>
	<td style='text-align:center;'><a href='' title='by StrikeREAD' rel=tooltip-r>There is currently no news right now, staff members are able to post news for there members here!</a></td>
<?php
					}
				?>
</table>

<h2>Information:</h2>
<table id='eix'>
<thead>
</thead>
<tbody>

<tr>
	<td style='text-align:center;'>Username:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo htmlentities($_SESSION['username']); ?></a></td>
<tr>
	<td style='text-align:center;'>Email:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $testInfo['email']; ?></a></td>
<tr>
	<td style='text-align:center;'>Referral Link:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $url.'index.php?referral='.strtolower($_SESSION['username']); ?></a></td>
<tr>
<tr>
<tr>
<tr>
	<td style='text-align:center;'>Membership:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $userInfo['name']; ?></a></td>
<tr>
	<td style='text-align:center;'>Membership Expiration:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo date('d-m-Y' ,$userInfo['expire']); ?></a></td>
<tr>
	<td style='text-align:center;'>Max Boot Time:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $userInfo['mbt']; ?> seconds</a></td>
<tr>
	<td style='text-align:center;'>Power available:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r>Full Power</a></td>
<tr>
<tr>
<tr>
<tr>
	<td style='text-align:center;'>Your Attacks:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $stats->totalBootsForUser($odb, $_SESSION['username']); ?></a></td>
<tr>
	<td style='text-align:center;'>Total Attacks:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $stats->totalBoots($odb); ?></a></td>
<tr>
	<td style='text-align:center;'>Total Users:</td>
	<td style='text-align:center;'><a href='' rel=tooltip-r><?php echo $stats->totalUsers($odb); ?></a></td>
</table>


</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>