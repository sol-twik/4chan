<?php

	require('includes/db.php');

	require('includes/init.php');

	if($user -> LoggedIn()){

		header('location: index.php');

		die();

	}

?>
<!DOCTYPE html>
<html>
<head>
<title>StrikeREAD Stresser | Register</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/style.css' />
<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<meta name='description' content='StrikeREAD Stresser Registeration page, best stress tool ever made.' />
<script type='text/javascript' src='https://code.jquery.com/jquery.min.js'></script>
<body>
<div id='header'>
<div style='float:left;'> 
<a href='register.php' class='menu_first'>Register</a>
<a href='login.php'>Login</a>
<a href='tos.php'>Tos</a>
</div>
<div style='float:left;margin-left: 75px;'>
</div>
</div>    

<div id='holder'>
<div id='logo'></div>
<div id='login_form'>
<form action="" id="validate" class="form" method="POST">
						<?php

									if(isset($_POST['registerBtn'])){

										require_once('includes/recaptchalib.php');

										$privatekey = "6Le15dMSAAAAAMt993qrA52wyqkzPlgRuLqehtiN";

										$resp = recaptcha_check_answer ($privatekey,

										$_SERVER["REMOTE_ADDR"],

										$_POST["recaptcha_challenge_field"],

										$_POST["recaptcha_response_field"]);

										$username = $_POST['username'];

										$password = $_POST['password'];

										$rpassword = $_POST['rpassword'];

										$email = $_POST['email'];

										$uid = $_POST['uid'];

										$checkUsername = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username");

										$checkUsername->execute(array(':username' => $username));

										$countUsername = $checkUsername -> fetchColumn(0);

										$checkUID = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `uid` = :uid");

										$checkUID->execute(array(':uid' => $uid));

										$countUID = $checkUID -> fetchColumn(0);

										$checkEmail = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `email` = :email");

										$checkEmail->execute(array(':email' => $email));

										$countEmail = $checkEmail -> fetchColumn(0);

										if(empty($username) || empty($password) || empty($rpassword) || empty($email) || empty($uid)){

											echo $design->alert('error', 'Error', 'Please Fill In All Fields!');

										} elseif(!isset($_POST['tos'])) {

											echo $design->alert('error', 'Error', 'You Must Agree To The Terms of Service!');

										} elseif(!$resp->is_valid) {

											echo $design->alert('error', 'Error', 'Error, you entered a invalid captcha!!');

										} else {

											if(!ctype_alnum($username) || strlen($username) < 4 || strlen($username) > 15){

												echo $design->alert('error', 'Error', 'Username Must Be 4 - 16 Characters!');

											} elseif(strlen($uid) < 1) {

												echo $design->alert('error', 'Error', 'Skype Must Be At Least 1 Character!');

											} else {

												if(!($countEmail == 0)){

													echo $design->alert('error', 'Error', 'Email Address Is Already Taken!');

												} elseif(!($countUsername == 0)) {

													echo $design->alert('error', 'Error', 'Username Is Already Taken!');

												}
												else {

													if(!filter_var($email, FILTER_VALIDATE_EMAIL)){

														echo $design->alert('error', 'Error', 'Invalid Email!');

													} else {

														if($password != $rpassword){

															echo $design->alert('error', 'Error', 'Passwords Do Not Match!');

														} else {

															if(isset($_SESSION['referral'])){

																$checkIP = $odb -> prepare("SELECT * FROM `referuser` WHERE `ip`='".SHA1($_SERVER['REMOTE_ADDR'])."'");

																$checkIP -> execute();

																$countIP = $checkIP -> rowCount();

																if($countIP != 1){

																	$checkUser = $odb -> prepare("SELECT * FROM `refers` WHERE `user`='".$_SESSION['referral']."'");

																	$checkUser -> execute();

																	$countUser = $checkUser -> rowCount();

																	if($countUser != 1){

																		$Insrefer = $odb -> prepare("INSERT INTO `refers` (user, referals) VALUES('".$_SESSION['referral']."', 1)");

																		$Insrefer -> execute();

																	} else {

																		$Insrefer = $odb -> prepare("UPDATE `refers` SET `referals`=`referals`+1 WHERE `user`='".$_SESSION['referral']."'");

																		$Insrefer -> execute();

																	}

																	$ReferUser = $odb -> prepare("INSERT INTO `referuser` (referrer, referred, ip) VALUES('".$_SESSION['referral']."', '".$username."', '".SHA1($_SERVER['REMOTE_ADDR'])."')");

																	$ReferUser -> execute();

																}

																session_unset($_SESSION['referral']);

															}

															$insertUser = $odb->prepare("INSERT INTO `users` VALUES(NULL, :username, :password, :email, :uid , 0, 0, 0, 0)");

															$insertUser->execute(array(':username' => $username, ':password' => SHA1($password), ':email' => $email, ':uid' => $uid));

															echo $design->alert('message', 'Success', 'Successfully Registered!');

															echo '<meta http-equiv="refresh" content="2;url=login.php">';

														}

													}

												}

											}

										}

									}

								?>

<script type="text/javascript">

									var RecaptchaOptions = {

										theme : 'black'

									};

</script>

Username:<br />
<input type="text" name="username" id="username" maxlength="15" class="login-input" placeholder="Your username" value=""/>
<div class="clear"></div>
Password:<br />
<input type="password" name="password" class="login-input" placeholder="Your password" id="pass" value=""/>
Password again:<br />
<input type="password" name="rpassword" class="login-input" placeholder="Repeat password" id="rpass" value=""/>
<div class="clear"></div>
Email:
<input type="email" name="email" class="login-input" placeholder="Your e-mail" id="email" value=""/>
<div class="clear"></div>
Skype:
<input class="login-input" placeholder="Skype" name="uid" type="text"/>
<div class="clear"></div><br />
<?php

										require_once('includes/recaptchalib.php');

										$publickey = "6Le15dMSAAAAABc-TeLmqmXqmjkSG2IWe2MVx1ym";

										echo recaptcha_get_html($publickey);

									?>						


<center><label><input type="checkbox" name="tos"/> Accept TOS</label>
<input type='submit' value='Register' id='Register' class='login-input' style='width:auto;cursor:pointer'; name='registerBtn'></center>									
</div>
</div>
<br />
<br />
</center>
</form>
</body>
</html>