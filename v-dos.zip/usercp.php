<?php
ob_start();
error_reporting(0);
require_once 'includes/db.php';
require_once 'includes/init.php';
if (!($user -> LoggedIn()))
{
	header('location: login.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
<script type="text/javascript" src='https://code.jquery.com/jquery.min.js'></script>

<title>StrikeREAD Stresser | Usercp</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/system.css' />
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>
<body>
	<div id='sidebar'>
	<?php 
	include("sidebar.php"); 
	?>
		 
<div class='content-page'>	
<h2>Change password:</h2>			
<form method="POST">
<?php 
											if(isset($_POST['updatePassBtn'])){
												$cpassword = $_POST['cpassword'];
												$npassword = $_POST['npassword'];
												$rpassword = $_POST['rpassword'];
												if(!empty($cpassword) && !empty($npassword) && !empty($rpassword)){
													if($npassword == $rpassword){
														$SQLCheckCurrent = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `password` = :password");
														$SQLCheckCurrent->execute(array(':username' => $_SESSION['username'], ':password' => SHA1($cpassword)));
														$countCurrent = $SQLCheckCurrent -> fetchColumn(0);
														if($countCurrent == 1){
															$SQLUpdate = $odb->prepare("UPDATE `users` SET `password` = :password WHERE `username` = :username AND `ID` = :id");
															$SQLUpdate->execute(array(':password' => SHA1($npassword),':username' => $_SESSION['username'], ':id' => $_SESSION['ID']));
															echo $design->alert('message', 'Success', 'Password Has Been Updated!');
														} else {
															echo $design->alert('error', 'Error', 'Current Password Is Incorrect!');
														}
													} else {
														echo $design->alert('error', 'Error', 'New Passwords Do Not Match!');
													}
												} else {
													echo $design->alert('error', 'Error', 'Please Fill In All Fields!');
												}
											}
										?>
												<input type="password" class="login-input" name="cpassword" placeholder="current password"/><br>
										
												<input type="password" class="login-input" name="npassword" placeholder="new password"/><br>
										
												<input type="password" class="login-input" name="rpassword" placeholder="repeat new password"/><br><br>
										
											<button type="submit" name="updatePassBtn" class="login-input">Update Password</button>
</form>

<br><br>
<h2>Referral Link : <?php echo $url.'index.php?referral='.strtolower($_SESSION['username']); ?> // Count :
												<?php
													$SQL = $odb->query("SELECT `referals` FROM `refers` WHERE `user` = '{$_SESSION['username']}'");
													$count =  $SQL->fetchColumn(0);
													if(empty($count)){
														echo '0';
													} else {
														echo $count;
													}
												?></h2>
<table id='eix'>
<thead>
<tr>
<td>Username</td>
<td>Active Plan</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
																		$getRefers = $odb->prepare("SELECT * FROM `referuser` WHERE `referrer` = :username");
																		$getRefers->execute(array(':username' => $_SESSION['username']));
																		while($getInfo = $getRefers->fetch(PDO::FETCH_ASSOC)){
																			$referred = $getInfo['referred'];
																	?>
	<td style='text-align:center;'><?php echo $referred; ?></td>
	<td style='text-align:center;'><?php
																				$activePlan = $odb->prepare("SELECT `expire` FROM `users` WHERE `username` = :username");
																				$activePlan->execute(array(':username' => $referred));
																				$expire = $activePlan->fetchColumn(0);
																				if(time() < $expire){
																					echo 'Yes';
																				} else {
																					echo 'No';
																				}
																			?>
										</td>
<tr>
<?php } ?>
</tbody>
</table>

<br><br>
<h2>Buy Logs:</h2>
<table id='eix'>
<thead>
<tr>
<td>UserID</td>
<td>Transaction ID</td>
<td>Date Payed</td>
<td>PayPal Email</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
													$paymentLogs = $odb->prepare("SELECT * FROM `payments` WHERE `user` = :userID ORDER BY `date` DESC");
													$paymentLogs->execute(array(':userID' => $_SESSION['ID']));
													while($getInfo = $paymentLogs->fetch(PDO::FETCH_ASSOC)){
														$user = $getInfo['user'];
														$email = $getInfo['email'];
														$tid = $getInfo['tid'];
														$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
												?>
	<td style='text-align:center;'><?php echo $user; ?></td>
	<td style='text-align:center;'><?php echo $tid; ?></td>
	<td style='text-align:center;'><?php echo $date; ?></td>
	<td style='text-align:center;'><?php echo $email; ?></td>
<tr>
<?php
													}
												?>
</tbody>
</table>

<br><br>
<h2>Login Logs:</h2>
<table id='eix'>
<thead>
<tr>
<td>UserID</td>
<td>Username</td>
<td>Logged</td>
<td>Date</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
															$loginLogs = $odb->prepare("SELECT * FROM `loginip` WHERE `username` = :username ORDER BY `date` DESC");
															$loginLogs->execute(array(':username' => $_SESSION['username']));
															while($getInfo = $loginLogs->fetch(PDO::FETCH_ASSOC)){
																$userID = $getInfo['userID'];
																$username = $getInfo['username'];
																$logged = $getInfo['logged'];
																$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
														?>
	<td style='text-align:center;'><?php echo $userID; ?></td>
	<td style='text-align:center;'><?php echo $username; ?></td>
	<td style='text-align:center;'><?php echo $logged; ?></td>
	<td style='text-align:center;'><?php echo $date; ?></td>
<tr>
<?php
													}
												?>
</tbody>
</table>

<h2>Attack Logs:</h2>
<table id='eix'>
<thead>
<tr>
<td>IP</td>
<td>Port <A title="Default : 80" rel='tooltip' herf='#' class='icon-info-sign'></a></h2> </td>
<td>Method</td>
<td>Time</td>
<td>Date</td>
</tr>
</thead>
<tbody>
<tr>
	<?php
				$SQLGetLogs = $odb -> query("SELECT * FROM `logs` WHERE user='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 0, 999999");
				while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
				{
					$IP = $getInfo['ip'];
					$port = $getInfo['port'];
					$time = $getInfo['time'];
					$method = $getInfo['method'];
					$date = date("d-m-Y, h:i:s a" ,$getInfo['date']);
				}
					
				?>
	<td style='text-align:center;'><?php echo $IP; ?></td>
	<td style='text-align:center;'><?php echo $port; ?></td>
	<td style='text-align:center;'><?php echo $method; ?></td>
	<td style='text-align:center;'><?php echo $time; ?></td>
	<td style='text-align:center;'><?php echo $date; ?></td>
<tr>
</tbody>
</table>
</div>
</tbody>

<script>
    $(".content-page").fadeIn(350);
</script>