<!DOCTYPE html><html><head><title>StrikeREAD - Terms of Service</title><meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<link rel='stylesheet' type='text/css' href='css/style.css' /><script type='text/javascript' src='https://code.jquery.com/jquery.min.js'></script><body><div id='header'><div style='float:left;'> <a href='register.php' class='menu_first'>Register</a><a href='login.php'>Login</a><a href='tos.php'>Tos</a></div><div style='float:right;margin-right: 75px;'></div></div><div id='logo'></div><center><h2>T.O.S:</h2>
1) By purchasing StrikeREAD Stresser you agree to our ToS.<br />
2) We are not responsible for how ever you use this stresser.<br />
3) You may not share your account, if you will, your account will be closed without a warning or a refund!<br />
4) We have the right to close any account we want or shut down the project at any time we want without a refund.<br />
5) No Refunds or chargebacks unless we decide , if you'll charge back a report will be filled.<br />
6) We have the right not to sell you any plan / spot in StrikeREAD.<br />
7) We have the right to change the ToS anytime we want.<br />
8) You're not allowed to use proxy or VPN to access StrikeREAD stresser.<br />
9) Disrespect will result in no more support & no more updates.<br />
10) You're not allowed to have more than 4 accounts. </center>
</body></html>