<?php
require 'includes/db.php';
require 'includes/init.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>StrikeREAD Stresser | Login</title>
<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
<meta name='description' content='StrikeREAD Stresser is one of the most powerful, stable and reliable stressers out there. We always do whatever it takes to keep our customers satisfied StrikeREAD Stresser also has a lot of custom made and unique features that you cannot find anywhere else! '/>
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="1 day">
<meta name="language" content="English">
<link rel='stylesheet' type='text/css' href='css/style.css' />
<script type='text/javascript' src='https://code.jquery.com/jquery.min.js'></script>
<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css' rel='stylesheet'>
<link href='css/font-awesome/css/font-awesome.css' rel='stylesheet' />
<script type='text/javascript' src='css/tooltip/tooltip_bootstrap.js'></script>
<script type='text/javascript' src='css/tooltip/tooltip.js'></script>
</head>

<body>
<div id='header'>
<div style='float:left;'> 
<a href='register.php' class='menu_first'>Register</a>
<a href='login.php'>Login</a>
<a href='tos.php'>Tos</a>

</div>
</div>
<div class='content-page'>
<div style='float:right;margin-right: 75px;'>
</div>
<div id='holder'>
<div id='logo'></div>
<div id='login_form'>

 <?php
							if (!($user -> LoggedIn()))
							{
								if (isset($_POST['loginBtn']))
								{
									$username = $_POST['username'];
									$password = $_POST['password'];
									$errors = array();
									if (!ctype_alnum($username) || strlen($username) < 4 || strlen($username) > 15)
									{
										$errors[] = '<div class="error" id="message">Username Must Be  Alphanumberic And 4-15 characters in length</div>';
									}
									
									if (empty($username) || empty($password))
									{
										$errors[] = '<div class="error" id="message">Please fill in all fields</div>';
									}
									
									if (empty($errors))
									{
										$SQLCheckLogin = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `password` = :password");
										$SQLCheckLogin -> execute(array(':username' => $username, ':password' => SHA1($password)));
										$countLogin = $SQLCheckLogin -> fetchColumn(0);
										if ($countLogin == 1)
										{
											$SQLGetInfo = $odb -> prepare("SELECT `username`, `ID` FROM `users` WHERE `username` = :username AND `password` = :password");
											$SQLGetInfo -> execute(array(':username' => $username, ':password' => SHA1($password)));
											$userInfo = $SQLGetInfo -> fetch(PDO::FETCH_ASSOC);
											if ($userInfo['status'] == 0)
											{
												$_SESSION['username'] = $userInfo['username'];
												$_SESSION['ID'] = $userInfo['ID'];
												echo '<div class="message" id="message"><p><strong>SUCCESS: </strong>Welcome '.$username.'!! Login Successful.  Redirecting....</p></div><meta http-equiv="refresh" content="3;url=index.php">';
											}
											else
											{
												echo '<div class="error" id="message"><p><strong>ERROR: </strong>Your user was banned</p></div>';
											}
										}
										else
										{
											echo '<div class="error" id="message"><p><strong>ERROR: </strong>Login Failed</p></div>';
										}
									}
									else
									{
										echo '<div class="error" id="message"><p><strong>ERROR:</strong><br /></div>';
										foreach($errors as $error)
										{
											echo ''.$error.'';
										}
										echo '</div>';
									}
								}
							}
							else
							{
								header('location: index.php');
							}
							?>

<form action="" id="validate" class="form" method="POST">
<br>
Username:<br />
<input type='text' id='username' class='login-input' name='username' value='' /><br />
Password:<br />
<input type='password' id='password' class='login-input' name='password' value='' /><br />
<input type='submit' value='Login' id='login' class='login-input' style='width:auto;cursor:pointer'; name='loginBtn'>
<input type='checkbox' name='tos'><A title='Read T.O.S' rel='tooltip-b' herf='tos.php'>Accept T.O.S</a><br>

</form>
</div>
</div>
<center>
<br>
<br>
<br>
By logging in you hereby agree to abide by the following <u><a href='tos.php'>Terms and Conditions</a></u>.<br>
Account got hacked / Forgot your password ? <u><a href='mail:strikeread@gmail.com'>contact</a></u> now!
</center>
</body>
</html></div>
    <script>
    $(".content-page").fadeIn(350);
    </script>